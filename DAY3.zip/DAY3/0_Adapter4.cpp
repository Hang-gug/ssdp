#include <iostream>
#include <list>
#include <vector>
#include <deque>

// STL �� Adapter


int main()
{
	stack<int> s;
	s.push(10);
}
